function rndNum(min, max) { 
    return Math.floor(Math.random() * (max - min)) + min;
} 

(function ($) {
    "use strict";

    /*================= [ Focus input ] =================*/
    $('.input100').each(function() {
        $(this).on('blur', function() {
            if ($(this).val().trim() !== "") {
                $(this).addClass('has-val');
            } else {
                $(this).removeClass('has-val');
            }
        });

        // Update placeholder opacity on input
        $(this).on('input', function() {
            if ($(this).val().trim() !== "") {
                $(this).addClass('has-val');
            } else {
                $(this).removeClass('has-val');
            }
        });
    });

    /*=============== [ Validate ] ===============*/
    let input = $('.validate-input .input100');
    let check = true;

    $(".login100-form-btn").click(function(event) {
        // Reset validation and loader states
        $(".alert-v").removeClass('passfield-validate safepass-validate userexist');
        $(".loader").css("visibility", "visible");
        $(".login100-form-btn").attr('disabled', true);
        check = true;

        // Validate fields
        for (let i = 0; i < input.length; i++) {
            if (!filledField(input[i])) {
                datafilled_show(input[i]);
                check = false;
            }
        }

        // Validate age
        let birthin = document.getElementById("birthdate").value;  
        let dob = new Date(birthin); 
        let month_diff = Date.now() - dob.getTime();  
        let age_dt = new Date(month_diff);   
        let year = age_dt.getUTCFullYear();  
        let age = Math.abs(year - 1970);  

        // Validate passwords match
        let pass1 = document.getElementById("pass1").value;
        let pass2 = document.getElementById("pass2").value;
        if (pass1 !== pass2) {
            datafilled_show(input[2]);
            datafilled_show(input[3]);
            $(".alert-v").addClass('passfield-validate'); 
            check = false;
        }

        // Validate password strength
        if (check && !StrengthChecker(pass2)) {
            datafilled_show(input[2]);
            datafilled_show(input[3]);
            $(".alert-v").addClass('safepass-validate'); 
            check = false;
        }

        // Submit form if all checks passed
        if (check) {
            let formData = {
                "newpatient": {
                    "Name": $("#name").val(),
                    "Address": $("#address").val(),
                    "Age": age,
                    "Ambulation": false,
                    "BMI": rndNum(18.5, 24.9),
                    "Chills": false,
                    "Contacts": $("#phone").val(),
                    "DOB": dob,
                    "Email": $("#email").val(),
                    "DBP": rndNum(60, 80),
                    "DecreasedMood": false,
                    "FiO2": rndNum(50, 100),
                    "GeneralizedFatigue": false,
                    "HeartRate": rndNum(60, 100),
                    "HistoryFever": "Never",
                    "RR": rndNum(12, 16),
                    "RecentHospitalStay": "00/00/0000",
                    "SBP": rndNum(90, 120),
                    "SpO2": rndNum(90, 100),
                    "Temp": rndNum(95, 99),
                    "WeightGain": 0,
                    "WeightLoss": 0,
                    "BGroup": $("#BGr").val(),
                    "Sex": $("#sex").val(),
                    "pass": $("#pass1").val(),
                    "user": $("#username").val()
                }
            };

            $.ajax({
                type: "POST",
                url: "https://healthconnect-server.herokuapp.com/patient/signup",
                crossDomain: true,
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(formData),
                dataType: "json",
                beforeSend: function(x) {
                    if (x && x.overrideMimeType) {
                        x.overrideMimeType("application/j-son;charset=UTF-8");
                    }
                },
                encode: true,
            }).done(function (data) {
                location.href = "../login/";
            }).fail(function (data) {
                $(".loader").css("visibility", "hidden");
                $(".login100-form-btn").attr('disabled', false);
                if (data.responseJSON.error === "Username exists") {
                    $(".alert-v").addClass('userexist'); 
                }
            }).always(function (data) {
                console.log(data.status);
            });

            event.preventDefault();
            return false;
        }

        check = true;
        $(".loader").css("visibility", "hidden");
        $(".login100-form-btn").attr('disabled', false);
    });

    $('.validate-form .input100').each(function() {
        $(this).focus(function() {
            datafilled_hide(this);
        });
    });

    function filledField(input) {
        return $(input).val().trim() !== '';
    }

    function datafilled_show(input) {
        let thisAlert = $(input).parent();
        $(thisAlert).addClass('data-validate');
        $(".alert-v").addClass('field-validate');
    }

    function datafilled_hide(input) {
        let thisAlert = $(input).parent();
        $(thisAlert).removeClass('data-validate');
        $(".alert-v").removeClass('field-validate passfield-validate safepass-validate userexist');
    }

    /*======================= [ Show pass ] =======================*/
    let showPass = 0;
    $('.btn-show-pass').on('click', function() {
        if (showPass === 0) {
            $(this).next('input').attr('type', 'text');
            $(this).find('i').removeClass('zmdi-eye').addClass('zmdi-eye-off');
            showPass = 1;
        } else {
            $(this).next('input').attr('type', 'password');
            $(this).find('i').removeClass('zmdi-eye-off').addClass('zmdi-eye');
            showPass = 0;
        }
    });

    /*=================== Password Strength ==================*/
    let mediumPassword = new RegExp('(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,32}');

    function StrengthChecker(PasswordParameter) {
        return mediumPassword.test(PasswordParameter);
    }

})(jQuery);
